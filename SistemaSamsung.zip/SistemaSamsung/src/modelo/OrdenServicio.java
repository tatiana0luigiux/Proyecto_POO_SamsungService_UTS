package modelo;
public class OrdenServicio {
    private int idOrden;
    private int idTecnico;
    private String clienteNombre;
    private String clienteDireccion;
    private String clienteTelefono;
    private String productoModelo;
    private String fallaReportada;
    private String fechaVisita;   // formato: yyyy-MM-dd
    private String rangoHorario;
    public OrdenServicio() {
    }
    public int getIdOrden() {
        return idOrden;
    }
    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }
    public int getIdTecnico() {
        return idTecnico;
    }
    public void setIdTecnico(int idTecnico) {
        this.idTecnico = idTecnico;
    }
    public String getClienteNombre() {
        return clienteNombre;
    }
    public void setClienteNombre(String clienteNombre) {
        this.clienteNombre = clienteNombre;
    }
    public String getClienteDireccion() {
        return clienteDireccion;
    }
    public void setClienteDireccion(String clienteDireccion) {
        this.clienteDireccion = clienteDireccion;
    }
    public String getClienteTelefono() {
        return clienteTelefono;
    }
    public void setClienteTelefono(String clienteTelefono) {
        this.clienteTelefono = clienteTelefono;
    }
    public String getProductoModelo() {
        return productoModelo;
    }
    public void setProductoModelo(String productoModelo) {
        this.productoModelo = productoModelo;
    }
    public String getFallaReportada() {
        return fallaReportada;
    }
    public void setFallaReportada(String fallaReportada) {
        this.fallaReportada = fallaReportada;
    }
    public String getFechaVisita() {
        return fechaVisita;
    }
    public void setFechaVisita(String fechaVisita) {
        this.fechaVisita = fechaVisita;
    }
    public String getRangoHorario() {
        return rangoHorario;
    }
    public void setRangoHorario(String rangoHorario) {
        this.rangoHorario = rangoHorario;
    }
}
