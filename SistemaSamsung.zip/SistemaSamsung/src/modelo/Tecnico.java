package modelo;

public class Tecnico {
    private int id_tecnico;
    private String cedula;
    private String nombre;
    private String especialidad;
    private String telefono;

    public Tecnico() {}

    public int getId_tecnico() { return id_tecnico; }
    public void setId_tecnico(int id_tecnico) { this.id_tecnico = id_tecnico; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}