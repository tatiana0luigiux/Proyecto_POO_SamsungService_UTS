
package vista;

/**
 *
 * @author Tatiana Ramírez y Luigi Rueda
 */
public class VistaOrdenes extends javax.swing.JFrame {
config.Conexion con1 = new config.Conexion();
java.sql.Connection conet;
javax.swing.table.DefaultTableModel modelo;
java.sql.Statement st;
java.sql.ResultSet rs;
private int idSeleccionado = -1; 

public VistaOrdenes() {
    initComponents();
    cargarRangos();
    cargarComboTecnicos();
    configurarTabla();
    consultar();
}
private void cargarRangos() {
    comboRangoHorario.removeAllItems();
    comboRangoHorario.addItem("MANANA");
    comboRangoHorario.addItem("TARDE");
}
private void cargarComboTecnicos() {
comboTecnico.removeAllItems();
    String sql = "SELECT id_tecnico, nombre FROM tecnicos ORDER BY nombre";
    try {
        conet = con1.getConnection();
        st = conet.createStatement();
        rs = st.executeQuery(sql);
        while (rs.next()) {
            int id = rs.getInt("id_tecnico");
            String nombre = rs.getString("nombre");
            comboTecnico.addItem(id + " - " + nombre);
        }
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error cargando técnicos: " + e.getMessage());
    }
}
private void configurarTabla() {
 tablaDatos.getSelectionModel().addListSelectionListener(e -> {
        if (e.getValueIsAdjusting()) return;
        int fila = tablaDatos.getSelectedRow();
        if (fila < 0) return;
        idSeleccionado = Integer.parseInt(tablaDatos.getValueAt(fila, 0).toString());
        txtIdOrden.setText(String.valueOf(tablaDatos.getValueAt(fila, 0)));
        txtClienteNombre.setText(String.valueOf(tablaDatos.getValueAt(fila, 2)));
        txtClienteDireccion.setText(String.valueOf(tablaDatos.getValueAt(fila, 3)));
        txtClienteTelefono.setText(String.valueOf(tablaDatos.getValueAt(fila, 4)));
        txtProductoModelo.setText(String.valueOf(tablaDatos.getValueAt(fila, 5)));
        txtFallaReportada.setText(String.valueOf(tablaDatos.getValueAt(fila, 6)));
        txtFechaVisita.setText(String.valueOf(tablaDatos.getValueAt(fila, 7)));
        comboRangoHorario.setSelectedItem(String.valueOf(tablaDatos.getValueAt(fila, 8)));
        int idTecnico = Integer.parseInt(tablaDatos.getValueAt(fila, 1).toString());
        seleccionarTecnicoEnCombo(idTecnico);
    });
}
void consultar() {
    String sql = "SELECT o.id_orden, "
               + "t.nombre AS tecnico_nombre, "
               + "o.cliente_nombre, "
               + "o.cliente_direccion, "
               + "o.cliente_telefono, "
               + "o.producto_modelo, "
               + "o.falla_reportada, "
               + "o.fecha_visita, "
               + "o.rango_horario "
               + "FROM ordenes_servicio o "
               + "INNER JOIN tecnicos t ON o.id_tecnico = t.id_tecnico "
               + "ORDER BY o.id_orden DESC";
    try {
        conet = con1.getConnection();
        st = conet.createStatement();
        rs = st.executeQuery(sql);
        modelo = (javax.swing.table.DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0);
        while (rs.next()) {
            modelo.addRow(new Object[]{
                rs.getInt("id_orden"),
                rs.getString("tecnico_nombre"), // ahora muestra nombre
                rs.getString("cliente_nombre"),
                rs.getString("cliente_direccion"),
                rs.getString("cliente_telefono"),
                rs.getString("producto_modelo"),
                rs.getString("falla_reportada"),
                rs.getDate("fecha_visita") != null ? rs.getDate("fecha_visita").toString() : "",
                rs.getString("rango_horario")
            });
        }
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error listando órdenes: " + e.getMessage());
    }
}
private void seleccionarTecnicoEnCombo(int idTecnico) {
    for (int i = 0; i < comboTecnico.getItemCount(); i++) {
        String item = comboTecnico.getItemAt(i).toString(); // "id - nombre"
        int id = Integer.parseInt(item.split(" - ")[0]);
        if (id == idTecnico) {
            comboTecnico.setSelectedIndex(i);
            return;
        }
    }
}
private void nuevo() {
    idSeleccionado = -1;
    txtIdOrden.setText("");
    txtClienteNombre.setText("");
    txtClienteDireccion.setText("");
    txtClienteTelefono.setText("");
    txtProductoModelo.setText("");
    txtFallaReportada.setText("");
    txtFechaVisita.setText("");
    tablaDatos.clearSelection();
    if (comboTecnico.getItemCount() > 0) comboTecnico.setSelectedIndex(0);
    if (comboRangoHorario.getItemCount() > 0) comboRangoHorario.setSelectedIndex(0);
}
private void guardar() {
    try {
        if (comboTecnico.getItemCount() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No hay técnicos registrados.");
            return;
        }
        String itemTecnico = comboTecnico.getSelectedItem().toString(); // "id - nombre"
        int idTecnico = Integer.parseInt(itemTecnico.split(" - ")[0]);
        String clienteNombre = txtClienteNombre.getText().trim();
        String clienteDireccion = txtClienteDireccion.getText().trim();
        String clienteTelefono = txtClienteTelefono.getText().trim();
        String productoModelo = txtProductoModelo.getText().trim();
        String fallaReportada = txtFallaReportada.getText().trim();
        String fechaTxt = txtFechaVisita.getText().trim();
        String rango = comboRangoHorario.getSelectedItem().toString();
        if (clienteNombre.isEmpty() || clienteDireccion.isEmpty() || clienteTelefono.isEmpty()
                || productoModelo.isEmpty() || fallaReportada.isEmpty() || fechaTxt.isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Complete todos los campos.");
            return;
        }
        java.sql.Date fecha = java.sql.Date.valueOf(fechaTxt); // yyyy-MM-dd
        if (idSeleccionado <= 0) {
            String sql = "INSERT INTO ordenes_servicio "
                    + "(id_tecnico, cliente_nombre, cliente_direccion, cliente_telefono, "
                    + "producto_modelo, falla_reportada, fecha_visita, rango_horario) "
                    + "VALUES (?,?,?,?,?,?,?,?)";
            try (java.sql.Connection c = con1.getConnection();
                 java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, idTecnico);
                ps.setString(2, clienteNombre);
                ps.setString(3, clienteDireccion);
                ps.setString(4, clienteTelefono);
                ps.setString(5, productoModelo);
                ps.setString(6, fallaReportada);
                ps.setDate(7, fecha);
                ps.setString(8, rango);
                ps.executeUpdate();
            }
            javax.swing.JOptionPane.showMessageDialog(this, "Orden registrada.");
        } else {
            String sql = "UPDATE ordenes_servicio SET "
                    + "id_tecnico=?, cliente_nombre=?, cliente_direccion=?, cliente_telefono=?, "
                    + "producto_modelo=?, falla_reportada=?, fecha_visita=?, rango_horario=? "
                    + "WHERE id_orden=?";
            try (java.sql.Connection c = con1.getConnection();
                 java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, idTecnico);
                ps.setString(2, clienteNombre);
                ps.setString(3, clienteDireccion);
                ps.setString(4, clienteTelefono);
                ps.setString(5, productoModelo);
                ps.setString(6, fallaReportada);
                ps.setDate(7, fecha);
                ps.setString(8, rango);
                ps.setInt(9, idSeleccionado);
                ps.executeUpdate();
            }
            javax.swing.JOptionPane.showMessageDialog(this, "Orden actualizada.");
        }
        consultar();
        nuevo();
    } catch (IllegalArgumentException ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Fecha inválida. Use formato yyyy-MM-dd");
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al guardar: " + ex.getMessage());
    }
}
private void eliminar() {
    int fila = tablaDatos.getSelectedRow();
    if (fila < 0) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione una orden en la tabla.");
        return;
    }
    int idOrden = Integer.parseInt(tablaDatos.getValueAt(fila, 0).toString());
    int op = javax.swing.JOptionPane.showConfirmDialog(
            this, "¿Eliminar esta orden?", "Confirmar",
            javax.swing.JOptionPane.YES_NO_OPTION);
    if (op != javax.swing.JOptionPane.YES_OPTION) return;
    String sql = "DELETE FROM ordenes_servicio WHERE id_orden=?";
    try (java.sql.Connection c = con1.getConnection();
         java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setInt(1, idOrden);
        ps.executeUpdate();
        javax.swing.JOptionPane.showMessageDialog(this, "Orden eliminada.");
        consultar();
        nuevo();
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error al eliminar: " + ex.getMessage());
    }
}
private void ruta() {
    try {
        if (comboTecnico.getItemCount() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "No hay técnicos registrados.");
            return;
        }
        String itemTecnico = comboTecnico.getSelectedItem().toString();
        int idTecnico = Integer.parseInt(itemTecnico.split(" - ")[0]);
        String sql = "SELECT * FROM ordenes_servicio "
                   + "WHERE id_tecnico = ? AND fecha_visita >= CURRENT_DATE "
                   + "ORDER BY fecha_visita, rango_horario";
        modelo = (javax.swing.table.DefaultTableModel) tablaDatos.getModel();
        modelo.setRowCount(0);
        try (java.sql.Connection c = con1.getConnection();
             java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTecnico);
            try (java.sql.ResultSet rs2 = ps.executeQuery()) {
                while (rs2.next()) {
                    modelo.addRow(new Object[]{
                        rs2.getInt("id_orden"),
                        rs2.getInt("id_tecnico"),
                        rs2.getString("cliente_nombre"),
                        rs2.getString("cliente_direccion"),
                        rs2.getString("cliente_telefono"),
                        rs2.getString("producto_modelo"),
                        rs2.getString("falla_reportada"),
                        rs2.getDate("fecha_visita") != null ? rs2.getDate("fecha_visita").toString() : "",
                        rs2.getString("rango_horario")
                    });
                }
            }
        }
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error en ruta: " + ex.getMessage());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtIdOrden = new javax.swing.JTextField();
        comboTecnico = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        txtClienteNombre = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtClienteDireccion = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtClienteTelefono = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtProductoModelo = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtFallaReportada = new javax.swing.JTextArea();
        txtFechaVisita = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        comboRangoHorario = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tablaDatos = new javax.swing.JTable();
        btnNuevo = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();
        btnListar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnHojaRuta = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("ID Orden:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 40, 59, -1));
        getContentPane().add(txtIdOrden, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 40, 71, -1));

        comboTecnico.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        getContentPane().add(comboTecnico, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, -1, -1));

        jLabel2.setText("Tecnicos:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 40, 52, -1));

        txtClienteNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClienteNombreActionPerformed(evt);
            }
        });
        getContentPane().add(txtClienteNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 90, 230, -1));

        jLabel3.setText("Nombre Cliente:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 103, -1));

        jLabel4.setText("Direccion:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 90, -1));
        getContentPane().add(txtClienteDireccion, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 232, -1));

        jLabel5.setText("Telefono:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, 90, -1));
        getContentPane().add(txtClienteTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 127, -1));

        jLabel6.setText("Producto:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 90, -1));
        getContentPane().add(txtProductoModelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 120, 127, -1));

        jLabel7.setText("Falla:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 90, -1));

        txtFallaReportada.setColumns(20);
        txtFallaReportada.setRows(5);
        jScrollPane1.setViewportView(txtFallaReportada);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 231, 45));
        getContentPane().add(txtFechaVisita, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 150, 125, -1));

        jLabel8.setText("Fecha de Visita:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 150, 90, -1));

        comboRangoHorario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MAÑANA", "TARDE" }));
        comboRangoHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboRangoHorarioActionPerformed(evt);
            }
        });
        getContentPane().add(comboRangoHorario, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 180, -1, -1));

        jLabel9.setText("Jornada de visita:");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, -1, -1));

        tablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ORDEN", "TECNICO", "CLIENTE", "DIRECCION", "TELEFONO", "PRODUCTO", "FALLA REPORTADA", "FECHA DE VISITA", "JORNADA"
            }
        ));
        jScrollPane2.setViewportView(tablaDatos);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 1020, 250));

        btnNuevo.setText("Nuevo");
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 40, -1, -1));

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, -1, -1));

        btnListar.setText("Listar");
        btnListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarActionPerformed(evt);
            }
        });
        getContentPane().add(btnListar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 100, -1, -1));

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 130, -1, -1));

        btnHojaRuta.setText("Ruta");
        btnHojaRuta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHojaRutaActionPerformed(evt);
            }
        });
        getContentPane().add(btnHojaRuta, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 160, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/LOGO.jpg"))); // NOI18N
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 10, 210, 210));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtClienteNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClienteNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClienteNombreActionPerformed

    private void comboRangoHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboRangoHorarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboRangoHorarioActionPerformed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
nuevo();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
guardar();
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarActionPerformed
consultar();
    }//GEN-LAST:event_btnListarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
eliminar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnHojaRutaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHojaRutaActionPerformed
ruta();
    }//GEN-LAST:event_btnHojaRutaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaOrdenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaOrdenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaOrdenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaOrdenes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaOrdenes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnHojaRuta;
    private javax.swing.JButton btnListar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JComboBox<String> comboRangoHorario;
    private javax.swing.JComboBox<String> comboTecnico;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tablaDatos;
    private javax.swing.JTextField txtClienteDireccion;
    private javax.swing.JTextField txtClienteNombre;
    private javax.swing.JTextField txtClienteTelefono;
    private javax.swing.JTextArea txtFallaReportada;
    private javax.swing.JTextField txtFechaVisita;
    private javax.swing.JTextField txtIdOrden;
    private javax.swing.JTextField txtProductoModelo;
    // End of variables declaration//GEN-END:variables
}
