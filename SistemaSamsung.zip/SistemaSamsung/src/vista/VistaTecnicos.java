
package vista;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class VistaTecnicos extends javax.swing.JFrame {
config.Conexion con1 = new config.Conexion();
    java.sql.Connection conet;
    javax.swing.table.DefaultTableModel modelo;
    java.sql.Statement st;
    java.sql.ResultSet rs;
    private int idSeleccionado = -1;
    public VistaTecnicos() {
        initComponents();
        configurarTabla();
        consultar(); 

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtCedula = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtEspecialidad = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaDatos = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 67, 71, -1));
        getContentPane().add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 101, 71, -1));

        txtEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEspecialidadActionPerformed(evt);
            }
        });
        getContentPane().add(txtEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 140, 71, -1));
        getContentPane().add(txtTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 169, 71, -1));

        jLabel1.setText("Cedula:");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 70, 49, -1));

        jLabel2.setText("Nombre:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 104, 49, -1));

        jLabel3.setText("Especialidad:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 138, 100, -1));

        jLabel4.setText("Telefono:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 172, -1, -1));

        jButton1.setText("Guardar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 80, -1, -1));

        jButton2.setText("Listar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, -1, -1));

        tablaDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Cedula", "Nombre", "Especialidad", "Telefono"
            }
        ));
        jScrollPane1.setViewportView(tablaDatos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 540, 250));

        jButton3.setText("Nuevo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 40, -1, -1));

        jButton4.setText("Eliminar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, -1, -1));

        jLabel5.setText("REGISTRO DE TECNICOS:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 200, 20));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/LOGO.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 0, 210, 210));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEspecialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEspecialidadActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        consultar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       guardar();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
idSeleccionado = -1;
tablaDatos.clearSelection();
txtCedula.setText("");
txtNombre.setText("");
txtEspecialidad.setText("");
txtTelefono.setText("");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
    eliminar();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaTecnicos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaTecnicos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaTecnicos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaTecnicos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VistaTecnicos().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaDatos;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables
void consultar() {
        String sql = "SELECT * FROM tecnicos"; // Asumiendo que tu compañero llamó "tecnicos" a la tabla
        try {
            conet = con1.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object[] tecnico = new Object[5];
            modelo = (javax.swing.table.DefaultTableModel) tablaDatos.getModel();
            modelo.setRowCount(0); 
            
            while (rs.next()) {
                tecnico[0] = rs.getInt("id_tecnico");
                tecnico[1] = rs.getString("cedula");
                tecnico[2] = rs.getString("nombre");
                tecnico[3] = rs.getString("especialidad");
                tecnico[4] = rs.getString("telefono");
                modelo.addRow(tecnico);
            }
            tablaDatos.setModel(modelo);
        } catch (Exception e) {
            System.err.println("Error listar: " + e);
        }
    }

    void guardar() {
    String ced = txtCedula.getText() != null ? txtCedula.getText().trim() : "";
    String nom = txtNombre.getText() != null ? txtNombre.getText().trim() : "";
    String esp = txtEspecialidad.getText() != null ? txtEspecialidad.getText().trim() : "";
    String tel = txtTelefono.getText() != null ? txtTelefono.getText().trim() : "";
    if (ced.isEmpty() || nom.isEmpty() || esp.isEmpty() || tel.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this, "Complete todos los campos.");
        return;
    }
    try {
        if (idSeleccionado <= 0) {
            String sql = "INSERT INTO tecnicos(cedula, nombre, especialidad, telefono) VALUES (?,?,?,?)";
            try (Connection c = con1.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, ced);
                ps.setString(2, nom);
                ps.setString(3, esp);
                ps.setString(4, tel);
                ps.executeUpdate();
            }
            javax.swing.JOptionPane.showMessageDialog(this, "Técnico registrado.");
        } else {
            String sql = "UPDATE tecnicos SET cedula=?, nombre=?, especialidad=?, telefono=? WHERE id_tecnico=?";
            try (Connection c = con1.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, ced);
                ps.setString(2, nom);
                ps.setString(3, esp);
                ps.setString(4, tel);
                ps.setInt(5, idSeleccionado);
                ps.executeUpdate();
            }
            javax.swing.JOptionPane.showMessageDialog(this, "Técnico actualizado.");
        }
        idSeleccionado = -1;
        txtCedula.setText("");
        txtNombre.setText("");
        txtEspecialidad.setText("");
        txtTelefono.setText("");
        tablaDatos.clearSelection();
        consultar();
    } catch (Exception e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
    private void configurarTabla() {
    tablaDatos.getSelectionModel().addListSelectionListener(e -> {
        if (e.getValueIsAdjusting()) {
            return;
        }
        int fila = tablaDatos.getSelectedRow();
        if (fila < 0) {
            return;
        }
        idSeleccionado = Integer.parseInt(tablaDatos.getValueAt(fila, 0).toString());
        txtCedula.setText(String.valueOf(tablaDatos.getValueAt(fila, 1)));
        txtNombre.setText(String.valueOf(tablaDatos.getValueAt(fila, 2)));
        txtEspecialidad.setText(String.valueOf(tablaDatos.getValueAt(fila, 3)));
        txtTelefono.setText(String.valueOf(tablaDatos.getValueAt(fila, 4)));
    });
}
    private void eliminar() {
    int fila = tablaDatos.getSelectedRow();
    if (fila < 0) {
        javax.swing.JOptionPane.showMessageDialog(this, "Seleccione una fila en la tabla.");
        return;
    }
    int id = Integer.parseInt(tablaDatos.getValueAt(fila, 0).toString());
    int op = javax.swing.JOptionPane.showConfirmDialog(
            this,
            "¿Eliminar este técnico?",
            "Confirmar",
            javax.swing.JOptionPane.YES_NO_OPTION);
    if (op != javax.swing.JOptionPane.YES_OPTION) {
        return;
    }
    String sql = "DELETE FROM tecnicos WHERE id_tecnico = ?";
    try (java.sql.Connection c = con1.getConnection();
         java.sql.PreparedStatement ps = c.prepareStatement(sql)) {
        ps.setInt(1, id);
        ps.executeUpdate();
        javax.swing.JOptionPane.showMessageDialog(this, "Técnico eliminado.");
    } catch (Exception ex) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "No se pudo eliminar:\n" + ex.getMessage()
                        + "\n(Si ese técnico tiene órdenes en la tabla ordenes_servicio, PostgreSQL no lo deja borrar.)");
        return;
    }
    idSeleccionado = -1;
    txtCedula.setText("");
    txtNombre.setText("");
    txtEspecialidad.setText("");
    txtTelefono.setText("");
    tablaDatos.clearSelection();
    consultar();
}
}
