package config;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexion {
    Connection con;
    
    public Connection getConnection() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ProyectoSamsung", "postgres", "1234");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de conexión a la Base de Datos: " + e.getMessage());
        }
        return con;
    }
}